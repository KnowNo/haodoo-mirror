ALiBaBar ver 5.10			Jan 26, 2005


Description:
A Internet Explorer add-on with the following features:-
1. Toggle display of Chinese webpage between traditional and simplified glyphs. 
2. Zoom in/out webpage's content 


System requirement:
Windows9x/Me/NT/2000/XP/2003
IE 5.5 or above


Installation:
Close all IE windows, and then run 'AlibabarXXX_Setup.exe' to install the program to designated folder.
After installation, a new toolbar named 'ALiBaBar' will appear in IE.
Unlock the toolbar if necessary, and drag it till all buttons are fully displayed.

Windows 2003 disable 3rd party IE plugin by default. Follow instuctions below to activate the plugin.
1. In IE's menu, select 'Tools>Internet Options>Advanced
2. check 'Enable third-party browser extensions'
3. restart IE
4. In menu, select 'View>Toolbar>ALiBaBar'

For MyIE2/Maxthon users, please follow the instructions below:
1. Terminate MyIE2/Maxthon, if it is running.
2. Open '[Location of MyIE2 or Maxthon]/Config/Plugins.ini' with Notepad.Add the line 'bLoadBHO=1' (quotation mark excluded) under [IEPlugins] section, and save it.
3. Start MyIE2/Maxthon
4. [MyIE2]	a. Menu: Options>MyIE2 Options>Advanced
		b. check 'Enable IE Plugin Support'
   [Maxthon]	a. Menu: Options>Maxthon Options>Plugins>IE Plugin
		b. check 'Enable IE Plugin Support'
5. [MyIE2]	Menu: Options>MyIE2 Options>Advanced>IE Plugin
   [Maxthon]	a. Menu: Options>Maxthon Options>Plugin>IE Plugin
		b. check 'ALiBaBar'         (for loading toolbar)
		c. check 'ALiBaBar_Helper'  (for loading BHO used for auto-converison)
6. Restart MyIE2/Maxthon
7. In MyIE2/Maxthon's menu, select 'View>Toolbar>Plugin


Uninstallation:
Close all running instances of IE/MyIE2/Maxthon.
Go to Control Panel>Add/Remove programs to remove Alibabar.


Note:
=======
The software is protected by copyright laws and international 
copyright treaties, as well as other intellectual property laws and treaties.

The software is free for single home user. Commerical use of the software
is strictly prohibited without authorization from the author.

The use of the software is done at your own risk. 
The author accepts no liability for any damages, either 
as direct or indirect consequence of the use of this product. 



Author  : Alfred, Li Chi Shing
Email   : lialfred@hkbn.net
Webpage: http://alf-li.pcdiscuss.com 
