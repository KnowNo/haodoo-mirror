#! /bin/sh
#
# $Id: build-updates.sh 7669 2011-10-19 00:14:54Z NiLuJe $
#

HACKNAME="jailbreak"
HACKDIR="linkjail"
PKGNAME="${HACKNAME}"
PKGVER="0.10.N"

# FW 2.x
KINDLE_MODELS="k2 k2i dx dxi dxg"
for model in ${KINDLE_MODELS} ; do
	# Prepare our files for this specific kindle model...
	ARCH=${PKGNAME}_${PKGVER}_${model}

	cp 2.5-${HACKNAME}.dat update_${ARCH}.dat
	cp 2.5-install.sh install.sh
	cp 2.5-install.sh.sig install.sh.sig

	# Build install update
	tar -czvf ${ARCH}.tgz install.sh install.sh.sig update-adds.tar.gz update_${ARCH}.dat
	./kindle_update_tool.py c --${model} ${ARCH}_install ${ARCH}.tgz

	# Cleanup our temp model-specific files
	rm -rf ${ARCH}.tgz update_${ARCH}.dat install.sh install.sh.sig

	# Build uninstall update
	./kindle_update_tool.py m --sign --${model} ${ARCH}_uninstall uninstall.sh
done

# FW 3.0.x
KINDLE_MODELS="k3g k3w k3gb"

#for model in ${KINDLE_MODELS} ; do
#	# Prepare our files for this specific kindle model...
#	ARCH=${PKGNAME}_${PKGVER}_${model}
#
#	cp 3.0-${HACKNAME}.dat update_${ARCH}.dat
#	cp 3.0-${HACKNAME}.dat.sig update_${ARCH}.dat.sig
#	cp 3.0-install.sh 3.0-jb-sig
#	ln -sf 3.0-jb-sig 490480060-490488060.ffs
#
#	# Build install update
#	tar -czvf ${ARCH}.tgz 490480060-490488060.ffs update_${ARCH}.dat update_${ARCH}.dat.sig 3.0-jb-sig
#	./kindle_update_tool.py c --${model} ${ARCH}_install ${ARCH}.tgz
#
#	# Cleanup our temp model-specific files
#	rm -rf ${ARCH}.tgz update_${ARCH}.dat update_${ARCH}.dat.sig 3.0-jb-sig 490480060-490488060.ffs
#
#	# Build uninstall update
#	./kindle_update_tool.py m --sign --${model} ${ARCH}_uninstall uninstall.sh
#done

# FW 3.0-3.2. Credits goes to yifanlu for this one, thanks! (http://yifan.lu/p/kindle-jailbreak)
# Archive custom directory
tar --exclude="*.svn" -cvzf ${HACKDIR}.tgz.sig ../src/${HACKDIR}

for model in ${KINDLE_MODELS} ; do
	# Prepare our files for this specific kindle model...
	ARCH=${PKGNAME}_${PKGVER}_${model}

	cp "3.0-${HACKNAME}.dat" "update ${ARCH}.sig .dat"
	cp "3.0-${HACKNAME}.dat.sig" "update ${ARCH}.sig .dat.sig"
	cp 3.1-install.sh 3.1-jb.sig
	cp linkjail-init linkjail-init.sig

	# Build our bundle file
	jb_md5sum=$( md5sum 3.1-jb.sig | awk '{ print $1; }' )
	jb_blocks=$(( $( stat -c %s 3.1-jb.sig ) / 64 ))
	echo "129 ${jb_md5sum} 3.1-jb.sig ${jb_blocks} 3.1-jb" > "${ARCH}.sig"

	# Build install update
	tar -czvf ${ARCH}.tgz "update ${ARCH}.sig .dat" "update ${ARCH}.sig .dat.sig" "${ARCH}.sig" "3.1-jb.sig" "${HACKDIR}.tgz.sig" "linkjail-init.sig"
	./kindle_update_tool.py c --${model} ${ARCH}_install ${ARCH}.tgz

	# Cleanup our temp model-specific files
	rm -rf ${ARCH}.tgz "update ${ARCH}.sig .dat" "update ${ARCH}.sig .dat.sig" "${ARCH}.sig" "3.1-jb.sig" "linkjail-init.sig"

	# Build uninstall update
	./kindle_update_tool.py m --sign --${model} ${ARCH}_uninstall 3.1-uninstall.sh
done

# FW 3.2.1-3.3. Credits goes to yifanlu & serge_levin for this one, thanks! (http://yifan.lu/p/kindle-jailbreak / http://www.mobileread.com/forums/showpost.php?p=1725629&postcount=151)
# NOTE: We need to build *BOTH*, because this one won't run on anything except >= v3.2.1, hence the -3.2.1 tag ;)

for model in ${KINDLE_MODELS} ; do
	# Prepare our files for this specific kindle model, and add a -3.2.1 tag to denote the fact that it will only run on FW versions newer than this ...
	ARCH=${PKGNAME}_${PKGVER}_${model}-3.2.1

	cp "3.0-${HACKNAME}.dat" "updatedat"
	cp "3.0-${HACKNAME}.dat.sig" "updatedat.sig"
	cp 3.1-install.sh 3.2.1-jb.sig
	cp linkjail-init linkjail-init.sig

	# Build our bundle file
	jb_md5sum=$( md5sum 3.2.1-jb.sig | awk '{ print $1; }' )
	jb_blocks=$(( $( stat -c %s 3.2.1-jb.sig ) / 64 ))
	echo "129 ${jb_md5sum} 3.2.1-jb.sig ${jb_blocks} 3.2.1-jb" > "update\dat"

	# Build install update
	tar -czvf ${ARCH}.tgz "updatedat" "updatedat.sig" "update\dat" "3.2.1-jb.sig" "${HACKDIR}.tgz.sig" "linkjail-init.sig"
	./kindle_update_tool.py c --${model} ${ARCH}_install ${ARCH}.tgz

	# Cleanup our temp model-specific files
	rm -rf ${ARCH}.tgz "updatedat" "updatedat.sig" "update\dat" "3.2.1-jb.sig" "linkjail-init.sig"

	# Build uninstall update (Same as before, so don't package it twice)
	#./kindle_update_tool.py m --sign --${model} ${ARCH}_uninstall 3.1-uninstall.sh
done

# Remove custom directory archive
rm -f ${HACKDIR}.tgz.sig

# Move our updates :)
mv -f *.bin ../
