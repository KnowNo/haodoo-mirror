#!/bin/sh
#
# FW 3.0.x-3.1 jailbreak install script.
#
# $Id: 3.1-install.sh 7632 2011-10-11 16:02:49Z NiLuJe $
#
##

export PATH=/usr/sbin:${PATH}

_FUNCTIONS=/etc/rc.d/functions
[ -f ${_FUNCTIONS} ] && . ${_FUNCTIONS}


MSG_SLLVL_D="debug"
MSG_SLLVL_I="info"
MSG_SLLVL_W="warn"
MSG_SLLVL_E="err"
MSG_SLLVL_C="crit"
MSG_SLNUM_D=0
MSG_SLNUM_I=1
MSG_SLNUM_W=2
MSG_SLNUM_E=3
MSG_SLNUM_C=4
MSG_CUR_LVL=/var/local/system/syslog_level

logmsg()
{
    local _NVPAIRS
    local _FREETEXT
    local _MSG_SLLVL
    local _MSG_SLNUM

    _MSG_LEVEL=$1
    _MSG_COMP=$2

    { [ $# -ge 4 ] && _NVPAIRS=$3 && shift ; }

    _FREETEXT=$3

    eval _MSG_SLLVL=\${MSG_SLLVL_$_MSG_LEVEL}
    eval _MSG_SLNUM=\${MSG_SLNUM_$_MSG_LEVEL}

    local _CURLVL

    { [ -f $MSG_CUR_LVL ] && _CURLVL=`cat $MSG_CUR_LVL` ; } || _CURLVL=1

    if [ $_MSG_SLNUM -ge $_CURLVL ]; then
        /usr/bin/logger -p local4.$_MSG_SLLVL -t "ota_install" "$_MSG_LEVEL def:$_MSG_COMP:$_NVPAIRS:$_FREETEXT"
    fi

    [ "$_MSG_LEVEL" != "D" ] && echo "ota_install: $_MSG_LEVEL def:$_MSG_COMP:$_NVPAIRS:$_FREETEXT"
}

if [ -z "${_PERCENT_COMPLETE}" ]; then
    export _PERCENT_COMPLETE=0
fi

update_percent_complete()
{
    _PERCENT_COMPLETE=$((${_PERCENT_COMPLETE} + $1))
    update_progressbar ${_PERCENT_COMPLETE}
}

# Hack specific config (name and when to start/stop)
HACKNAME="linkjail"
SLEVEL="64"
KLEVEL="09"

update_percent_complete 2

# Check if another jailbreak isn't already installed
if [ -f /etc/init.d/jailbreak -a -h /etc/rc5.d/S64jailbreak -a -h /etc/rc3.d/K09jailbreak -a -f /etc/uks/pubprodkey01.hack.pem ] ; then
    # yifanlu's jailbreak seems to be fully installed, abort, log it, and then try to warn the user in a visible way, without having to go digging in the logs.
    logmsg "E" "update" "Another jailbreak is already installed, aborting."

    # Print a visible message, in place of the error code, for 10s
    for jb_countdown in $(seq 1 10) ; do
        eips 1 $((${SCREEN_Y_RES} / ${EIPS_Y_RES} - 2)) "Found another jailbreak, aborting${jb_spinner}"
        jb_spinner="${jb_spinner}."
        sleep 1
    done

    return 1
fi

update_progressbar 4

# Check that our public keys aren't in an inconsistent state (ie. after a borked jailbreak uninstall, or before a full restart just after an uninstall of some jailbreak versions)
# NOTE/FIXME/IMDUMB: This is pretty much unreachable with jailbreaks targeting FW >= 3.1, otaup would already have died with a U007 error *before* we even got a chance to run.
pk_unexpected_md5="7130ce39bb3596c5067cabb377c7a9ed"
pk_current_md5="$( md5sum /etc/uks/pubprodkey01.pem )"
if [ "${pk_current_md5}" == "${pk_unexpected_md5}" ] ; then
    # We found our custom hack key, when we should have found the original pubkey, abort, log, and warn the user.
    logmsg "E" "update" "Inconsistent pubkey state (found: hack, expected: original), aborting."

    # We're gonna need some space...
    eips 1 $((${SCREEN_Y_RES} / ${EIPS_Y_RES} - 5)) "Found traces of another jailbreak..."
    eips 1 $((${SCREEN_Y_RES} / ${EIPS_Y_RES} - 4)) "Make sure one is not already installed, then"
    eips 1 $((${SCREEN_Y_RES} / ${EIPS_Y_RES} - 3)) "try again after a full restart of your Kindle."
    # Print a visible message, in place of the error code, for 10s
    for jb_countdown in $(seq 1 10) ; do
        eips 1 $((${SCREEN_Y_RES} / ${EIPS_Y_RES} - 2)) "Aborting${jb_spinner}"
        jb_spinner="${jb_spinner}."
        sleep 1
    done

    return 1
fi

update_progressbar 7

# Install our key (In case we're still on FW 3.0.x)
logmsg "I" "update" "installing our custom public key"
cat <<EOF > /etc/uks/pubhackkey01.pem
-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDJn1jWU+xxVv/eRKfCPR9e47lP
WN2rH33z9QbfnqmCxBRLP6mMjGy6APyycQXg3nPi5fcb75alZo+Oh012HpMe9Lnp
eEgloIdm1E4LOsyrz4kttQtGRlzCErmBGt6+cAVEV86y2phOJ3mLk0Ek9UQXbIUf
rvyJnS2MKLG2cczjlQIDAQAB
-----END PUBLIC KEY-----
EOF

update_progressbar 14

# Install our hack's custom content
# But keep the user's custom content...
if [ -d /mnt/us/${HACKNAME} ] ; then
    logmsg "I" "update" "our custom directory already exists, checking if we have custom content to preserve"
    # Hacks whitelist
    wl_expected_md5="a53a46af6eaedd72eff8b6bedfb095da de2ce68ad1812c7ea28117517f40952e 3d79664c8d4c6550aeda9e62b34fd039 507b1c8af223ec03e29a4915a074d86c d601fbdaaf5f83647e6ce66b63dbf916 b8e1cb5c9fa1fc209f9f041c797aeb7c b76db0b6c1a137b116fb95034f33125b 81620f70e8c7ca531c1841c7360908ba 56c0dd27149dbb544fdcae7d5aef6010 5f664336774e85352074c7e7a1c25a30 11140f7cc69f72633413cb56629e364a cbfcc2c7af55dfb53981e2a3d9e5d3bd 69e6c18048ae3141adea594303113931"
    # And perform the actual check
    wl_md5_match="false"
    # Check if it exists at all...
    if [ -f /mnt/us/${HACKNAME}/etc/whitelist ] ; then
        wl_current_md5=$( md5sum /mnt/us/${HACKNAME}/etc/whitelist | awk '{ print $1; }' )
        for cur_exp_md5 in ${wl_expected_md5} ; do
            if [ "${wl_current_md5}" == "${cur_exp_md5}" ] ; then
                wl_md5_match="true"
            fi
        done
        if [ "${wl_md5_match}" != "true" ] ; then
            HACK_EXCLUDE="/mnt/us/${HACKNAME}/etc/whitelist"
            logmsg "I" "update" "found custom whitelist, excluding from archive"
        fi
    else
        logmsg "I" "update" "custom whitelist missing, it'll be installed"
    fi
fi

update_progressbar 28

# Okay, now we can extract it. Since busybox's tar is very limited, we have to use a tmp directory to perform our filtering
logmsg "I" "update" "installing custom directory"
tar -xvzf ${HACKNAME}.tgz.sig

# That's very much inspired from official update scripts ;)
cd src
# And now we filter the content to preserve user's custom content
for custom_file in ${HACK_EXCLUDE} ; do
    if [ -f "./${custom_file}" ] ; then
        logmsg "I" "update" "preserving custom content (${custom_file})"
        rm -f "./${custom_file}"
    fi
done
# Finally, re-tape our filtered dir and unleash it on the live userstore
tar cf - . | (cd /mnt/us ; tar xvf -)
_RET=$?
if [ ${_RET} -ne 0 ] ; then
    logmsg "C" "update" "code=${_RET}" "failure to update userstore with custom directory"
    return 1
fi
cd - >/dev/null
rm -rf src

update_progressbar 42

# Install our hack's init script
logmsg "I" "update" "installing init script"
cp -f ${HACKNAME}-init.sig /etc/init.d/${HACKNAME}

update_progressbar 56

# Make it executable
logmsg "I" "update" "chmoding init script"
[ -x /etc/init.d/${HACKNAME} ] || chmod +x /etc/init.d/${HACKNAME}

update_progressbar 70

# Make it start (stop, actually) at boot (rc5), after dbus and before pmond and the framework
logmsg "I" "update" "creating boot runlevel symlink"
[ -h /etc/rc5.d/S${SLEVEL}${HACKNAME} ] || ln -fs /etc/init.d/${HACKNAME} /etc/rc5.d/S${SLEVEL}${HACKNAME}

update_progressbar 84

# Make it stop (start, actually) when updating (rc3), after the framework and before the updater
logmsg "I" "update" "creating update runlevel symlink"
[ -h /etc/rc3.d/K${KLEVEL}${HACKNAME} ] || ln -fs /etc/init.d/${HACKNAME} /etc/rc3.d/K${KLEVEL}${HACKNAME}

update_progressbar 98

# Cleanup
logmsg "I" "update" "cleaning up"
rm -f ${HACKNAME}-init.sig ${HACKNAME}.tgz.sig

update_progressbar 99

logmsg "I" "update" "done"
update_progressbar 100

return 0
