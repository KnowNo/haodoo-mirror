#!/bin/sh
#
# $Id: uninstall.sh 7230 2010-11-19 22:09:44Z NiLuJe $
#
# diff OTA patch script

_FUNCTIONS=/etc/rc.d/functions
[ -f ${_FUNCTIONS} ] && . ${_FUNCTIONS}


MSG_SLLVL_D="debug"
MSG_SLLVL_I="info"
MSG_SLLVL_W="warn"
MSG_SLLVL_E="err"
MSG_SLLVL_C="crit"
MSG_SLNUM_D=0
MSG_SLNUM_I=1
MSG_SLNUM_W=2
MSG_SLNUM_E=3
MSG_SLNUM_C=4
MSG_CUR_LVL=/var/local/system/syslog_level

logmsg()
{
    local _NVPAIRS
    local _FREETEXT
    local _MSG_SLLVL
    local _MSG_SLNUM

    _MSG_LEVEL=$1
    _MSG_COMP=$2

    { [ $# -ge 4 ] && _NVPAIRS=$3 && shift ; }

    _FREETEXT=$3

    eval _MSG_SLLVL=\${MSG_SLLVL_$_MSG_LEVEL}
    eval _MSG_SLNUM=\${MSG_SLNUM_$_MSG_LEVEL}

    local _CURLVL

    { [ -f $MSG_CUR_LVL ] && _CURLVL=`cat $MSG_CUR_LVL` ; } || _CURLVL=1

    if [ $_MSG_SLNUM -ge $_CURLVL ]; then
        /usr/bin/logger -p local4.$_MSG_SLLVL -t "ota_install" "$_MSG_LEVEL def:$_MSG_COMP:$_NVPAIRS:$_FREETEXT"
    fi

    [ "$_MSG_LEVEL" != "D" ] && echo "ota_install: $_MSG_LEVEL def:$_MSG_COMP:$_NVPAIRS:$_FREETEXT"
}

if [ -z "${_PERCENT_COMPLETE}" ]; then
    export _PERCENT_COMPLETE=0
fi

update_percent_complete()
{
    _PERCENT_COMPLETE=$((${_PERCENT_COMPLETE} + $1))
    update_progressbar ${_PERCENT_COMPLETE}
}

# Hack specific config (name and when to start/stop)
HACKNAME="linkfonts"
SLEVEL="62"
KLEVEL="07"

update_percent_complete 2

# From v3.1.N
logmsg "I" "update" "removing boot symlink from <= v3.1.N"
[ -h /etc/rcS.d/S73${HACKNAME} ] && rm -f /etc/rcS.d/S73${HACKNAME}

update_progressbar 8

# From v3.2.N
logmsg "I" "update" "removing messed up symlinks from v3.2.N"
[ -h /etc/rc6.d/K7${HACKNAME} ] && rm -f /etc/rc6.d/K7${HACKNAME}
[ -h /etc/rc0.d/K7${HACKNAME} ] && rm -f /etc/rc0.d/K7${HACKNAME}
[ -h /etc/rc3.d/K7${HACKNAME} ] && rm -f /etc/rc3.d/K7${HACKNAME}

update_progressbar 16

# From v4.1.N
logmsg "I" "update" "removing boot symlink from <= v4.1.N"
[ -h /etc/rc5.d/S72${HACKNAME} ] && rm -f /etc/rc5.d/S72${HACKNAME}

update_progressbar 26

# From v3.3.N
# Boot symlink
logmsg "I" "update" "removing boot symlink"
[ -h /etc/rc5.d/S${SLEVEL}${HACKNAME} ] && rm -f /etc/rc5.d/S${SLEVEL}${HACKNAME}

update_progressbar 34

# Reboot symlink
logmsg "I" "update" "removing reboot symlink"
[ -h /etc/rc6.d/K${KLEVEL}${HACKNAME} ] && rm -f /etc/rc6.d/K${KLEVEL}${HACKNAME}

update_progressbar 42

# Shutdown symlink
logmsg "I" "update" "removing shutdown symlink"
[ -h /etc/rc0.d/K${KLEVEL}${HACKNAME} ] && rm -f /etc/rc0.d/K${KLEVEL}${HACKNAME}

update_progressbar 50

# Updater symlink
logmsg "I" "update" "removing update symlink"
[ -h /etc/rc3.d/K${KLEVEL}${HACKNAME} ] && rm -f /etc/rc3.d/K${KLEVEL}${HACKNAME}

update_progressbar 58

# Remove our hack's init script
logmsg "I" "update" "removing init script"
[ -f /etc/init.d/${HACKNAME} ] && rm -f /etc/init.d/${HACKNAME}

update_progressbar 66

# From v4.1.N
logmsg "I" "update" "removing deprecated config file from v4.1.N"
if [ -f /etc/kdb/system/daemon/pmond/browserd/env ] ; then
    # Only remove it if it's actually our own!
    if grep '^LD_LIBRARY_PATH=/mnt/us/linkfonts/lib$' /etc/kdb/system/daemon/pmond/browserd/env > /dev/null 2>&1 ; then
        logmsg "I" "update" "custom deprecated config file found, removing"
        rm -f /etc/kdb/system/daemon/pmond/browserd/env
    fi
    # Also remove blank files
    if [ "$( stat -c %s /etc/kdb/system/daemon/pmond/browserd/env )" == "0" ] ; then
        logmsg "I" "update" "buggy deprecated config file found, removing"
        rm -f /etc/kdb/system/daemon/pmond/browserd/env
    fi
fi

update_progressbar 74

# From v4.2.N
logmsg "I" "update" "removing config file from v4.2.N"
if [ -f /etc/kdb/system/daemon/pmond/browserd/env ] ; then
    # Only remove it if it's actually our own!
    if grep '^OH_HAI_LINKFONTS=true$' /etc/kdb/system/daemon/pmond/browserd/env > /dev/null 2>&1 ; then
        logmsg "I" "update" "custom config file found, removing"
        rm -f /etc/kdb/system/daemon/pmond/browserd/env
    fi
fi

update_progressbar 82

# From v3.8.N
# Remove custom fontconfig cache (FW 3.x only)
if [ -d /var/local/cache/fontconfig ] ; then
    logmsg "I" "update" "removing custom fontconfig cache directory"
    rm -rf /var/local/cache/fontconfig
fi

update_progressbar 90

# From v3.7.N
# Remove custom directory in userstore?
logmsg "I" "update" "removing custom directory (only if /mnt/us/${HACKNAME}/uninstall exists)"
[ -d /mnt/us/${HACKNAME} -a -f /mnt/us/${HACKNAME}/uninstall ] && rm -rf /mnt/us/${HACKNAME}

update_progressbar 95

logmsg "I" "update" "done"
update_progressbar 100

return 0
