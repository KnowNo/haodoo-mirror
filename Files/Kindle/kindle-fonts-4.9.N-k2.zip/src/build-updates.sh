#! /bin/sh
#
# $Id: build-updates.sh 7669 2011-10-19 00:14:54Z NiLuJe $
#

HACKNAME="linkfonts"
PKGNAME="${HACKNAME##*link}"
PKGVER="4.9.N"

# K2 (Don't bundle extra K3 only fonts & utils (my current fc-scan binary doesn't run on K2 devices anyway), to save a bit of space)
KINDLE_MODELS="k2 k2i dx dxi dxg"

# Archive custom directory
tar --exclude="*.svn" --exclude="*Caecilia_LT_*.ttf" --exclude="*Helvetica_LT_*.ttf" --exclude="*KindleBlackbox*.ttf" --exclude="*Kindle_*Symbol.ttf" --exclude="code2000.ttf" --exclude="HangulGothMTC_E*.ttf" --exclude="HeiSeiMaruGoth213_E*.ttf" --exclude="MHeiM18030_E*.ttf" --exclude="MHeiM-Big5HKSCS_E*.ttf" --exclude="CJK.ttf" --exclude="I18N.ttf" --exclude="fc-scan" -cvzf ${HACKNAME}.tar.gz ../src/${HACKNAME}

for model in ${KINDLE_MODELS} ; do
	# Prepare our files for this specific kindle model...
	ARCH=${PKGNAME}_${PKGVER}_${model}

	# Build install update
	./kindle_update_tool.py m --${model} --sign ${ARCH}_install install.sh ${HACKNAME}-init ${HACKNAME}.tar.gz

	# Build uninstall update
	./kindle_update_tool.py m --${model} --sign ${ARCH}_uninstall uninstall.sh
done

# Remove custom directory archive
rm -f ${HACKNAME}.tar.gz

# K3
KINDLE_MODELS="k3g k3w k3gb"

# Archive custom directory
tar --exclude="*.svn" --exclude="*Caecilia_LT_*.ttf" --exclude="*Helvetica_LT_*.ttf" --exclude="*KindleBlackbox*.ttf" --exclude="*Kindle_*Symbol.ttf" --exclude="code2000.ttf" --exclude="HangulGothMTC_E*.ttf" --exclude="HeiSeiMaruGoth213_E*.ttf" --exclude="MHeiM18030_E*.ttf" --exclude="MHeiM-Big5HKSCS_E*.ttf" -cvzf ${HACKNAME}.tar.gz ../src/${HACKNAME}

for model in ${KINDLE_MODELS} ; do
	# Prepare our files for this specific kindle model...
	ARCH=${PKGNAME}_${PKGVER}_${model}

	# Build install update
	./kindle_update_tool.py m --${model} --sign ${ARCH}_install install.sh ${HACKNAME}-init ${HACKNAME}.tar.gz

	# Build uninstall update
	./kindle_update_tool.py m --${model} --sign ${ARCH}_uninstall uninstall.sh
done

# Remove custom directory archive
rm -f ${HACKNAME}.tar.gz

# Move our updates :)
mv -f *.bin ../
