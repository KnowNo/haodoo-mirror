#!/bin/sh
#
# $Id: install.sh 7536 2011-08-24 15:29:24Z NiLuJe $
#
# diff OTA patch script

_FUNCTIONS=/etc/rc.d/functions
[ -f ${_FUNCTIONS} ] && . ${_FUNCTIONS}


MSG_SLLVL_D="debug"
MSG_SLLVL_I="info"
MSG_SLLVL_W="warn"
MSG_SLLVL_E="err"
MSG_SLLVL_C="crit"
MSG_SLNUM_D=0
MSG_SLNUM_I=1
MSG_SLNUM_W=2
MSG_SLNUM_E=3
MSG_SLNUM_C=4
MSG_CUR_LVL=/var/local/system/syslog_level

logmsg()
{
    local _NVPAIRS
    local _FREETEXT
    local _MSG_SLLVL
    local _MSG_SLNUM

    _MSG_LEVEL=$1
    _MSG_COMP=$2

    { [ $# -ge 4 ] && _NVPAIRS=$3 && shift ; }

    _FREETEXT=$3

    eval _MSG_SLLVL=\${MSG_SLLVL_$_MSG_LEVEL}
    eval _MSG_SLNUM=\${MSG_SLNUM_$_MSG_LEVEL}

    local _CURLVL

    { [ -f $MSG_CUR_LVL ] && _CURLVL=`cat $MSG_CUR_LVL` ; } || _CURLVL=1

    if [ $_MSG_SLNUM -ge $_CURLVL ]; then
        /usr/bin/logger -p local4.$_MSG_SLLVL -t "ota_install" "$_MSG_LEVEL def:$_MSG_COMP:$_NVPAIRS:$_FREETEXT"
    fi

    [ "$_MSG_LEVEL" != "D" ] && echo "ota_install: $_MSG_LEVEL def:$_MSG_COMP:$_NVPAIRS:$_FREETEXT"
}

if [ -z "${_PERCENT_COMPLETE}" ]; then
    export _PERCENT_COMPLETE=0
fi

update_percent_complete()
{
    _PERCENT_COMPLETE=$((${_PERCENT_COMPLETE} + $1))
    update_progressbar ${_PERCENT_COMPLETE}
}

# Hack specific config (name and when to start/stop)
HACKNAME="linkfonts"
SLEVEL="62"
KLEVEL="07"

update_percent_complete 2

# Remove our deprecated content
# From v3.1.N
logmsg "I" "update" "removing deprecated symlinks (<= v3.1.N)"
[ -h /etc/rcS.d/S73${HACKNAME} ] && rm -f /etc/rcS.d/S73${HACKNAME}

update_progressbar 6

# From v3.2.N
logmsg "I" "update" "removing deprecated symlinks (v3.2.N)"
[ -h /etc/rc6.d/K7${HACKNAME} ] && rm -f /etc/rc6.d/K7${HACKNAME}
[ -h /etc/rc0.d/K7${HACKNAME} ] && rm -f /etc/rc0.d/K7${HACKNAME}
[ -h /etc/rc3.d/K7${HACKNAME} ] && rm -f /etc/rc3.d/K7${HACKNAME}

update_progressbar 12

# From v3.8.N
logmsg "I" "update" "removing deprecated config files (<= v3.8.N)"
HACK_CFGLIST="font.properties-2 font.properties-3 font.properties-3-nocondensed font.properties fonts.conf local.conf local.conf.template netfront.ini prettyversion.txt"
for hack_cfg in ${HACK_CFGLIST} ; do
    [ -f /mnt/us/${HACKNAME}/bin/${hack_cfg} ] && rm -f /mnt/us/${HACKNAME}/bin/${hack_cfg}
done

update_progressbar 18

# From v4.1.N
logmsg "I" "update" "removing deprecated config file (v4.1.N)"
if [ -f /etc/kdb/system/daemon/pmond/browserd/env ] ; then
    # Only remove it if it's actually our own!
    if grep '^LD_LIBRARY_PATH=/mnt/us/linkfonts/lib$' /etc/kdb/system/daemon/pmond/browserd/env > /dev/null 2>&1 ; then
        logmsg "I" "update" "custom deprecated config file found, removing"
        rm -f /etc/kdb/system/daemon/pmond/browserd/env
    fi
    # Also remove blank files
    if [ "$( stat -c %s /etc/kdb/system/daemon/pmond/browserd/env )" == "0" ] ; then
        logmsg "I" "update" "buggy deprecated config file found, removing"
        rm -f /etc/kdb/system/daemon/pmond/browserd/env
    fi
fi
# And remove the useless copy we had in linkfonts/etc
[ -f /mnt/us/${HACKNAME}/etc/env ] && rm -f /mnt/us/${HACKNAME}/etc/env

update_progressbar 24

# From v4.2.N
logmsg "I" "update" "removing config file (v4.2.N)"
if [ -f /etc/kdb/system/daemon/pmond/browserd/env ] ; then
    # Only remove it if it's actually our own!
    if grep '^OH_HAI_LINKFONTS=true$' /etc/kdb/system/daemon/pmond/browserd/env > /dev/null 2>&1 ; then
        logmsg "I" "update" "custom config file found, removing"
        rm -f /etc/kdb/system/daemon/pmond/browserd/env
    fi
fi

update_progressbar 30

# From v4.1.N
logmsg "I" "update" "removing deprecated symlink (<= v4.1.N)"
[ -h /etc/rc5.d/S72${HACKNAME} ] && rm -f /etc/rc5.d/S72${HACKNAME}

update_progressbar 36

# Install our hack's custom content
# But keep the user's custom content...
if [ -d /mnt/us/${HACKNAME} ] ; then
    logmsg "I" "update" "our custom directory already exists, checking if we have custom content to preserve"
    # Custom Fonts
    # Loop through all of our custom fonts
    for font_type in Serif Sans Mono ; do
        for font_style in Regular Bold Italic BoldItalic ; do
            current_font="${font_type}_${font_style}.ttf"
            # Select the correct expected md5sum for our current font
            case "${current_font}" in
                "Serif_Regular.ttf" )
                    font_expected_md5="e18165ce2b700b1b4daca82e276fcac5 bfb2f44a7c1deba39f7f4d39bff18eeb"
                ;;
                "Serif_Bold.ttf" )
                    font_expected_md5="3b6c3214b028debd9f175b63f71508e0 849a92990a80cbb665bfc74fd03743bd"
                ;;
                "Serif_Italic.ttf" )
                    font_expected_md5="1262ad9a9f243ef2e7c80c0bb5f0060d a2e7305a0ba8bb7091124f4cd1485fc9"
                ;;
                "Serif_BoldItalic.ttf" )
                    font_expected_md5="1f5dc2bf62705a7d09533b1538c9c173 a062025df92affc1331a05b7c07793fc"
                ;;
                "Sans_Regular.ttf" )
                    font_expected_md5="9e94decf013d3e2c9adcc0b97cc5ce44 9d83fb20700a3a7c45dc9acd64ab121e"
                ;;
                "Sans_Bold.ttf" )
                    font_expected_md5="3c0f650c88f1dd66abf4e2d86b2789b8 2afdf28d5cdd079b41968cdabf1b469e"
                ;;
                "Sans_Italic.ttf" )
                    font_expected_md5="ee14498581142ad399d0b7bfb1d70e3f 6f065779222f5f541356ae7c75dc93fd 5f2a66bd428ec6b298687d9337cb4395"
                ;;
                "Sans_BoldItalic.ttf" )
                    font_expected_md5="a853c46d69c39abc45d15601c7c8b5c1 b71566eb8206848f8314ec8ac5a77e36 139e3a3f44fae921c174554f3754de04"
                ;;
                "Mono_Regular.ttf" )
                    font_expected_md5="0fa23684c88737952788b01bba227ea9 84d533cd5ab154ad1cea6f3a6b46236d 3909da5d4d4df4dea6426e54f622cb28"
                ;;
                "Mono_Bold.ttf" )
                    font_expected_md5="26dd9aa93361477f10b4f949a0a76a61 9a0c0532173736ac68650aad297b8e1d 73dbc55a8e9e588e338f467d8998e358"
                ;;
                "Mono_Italic.ttf" )
                    font_expected_md5="f5b435e042123f193035256df7f70d4a 585945d85b03549f3a4c4cc661f57617 7ac5d510e1c436a4f8cb8e1f66bed302"
                ;;
                "Mono_BoldItalic.ttf" )
                    font_expected_md5="44f2c073f5676fcf0c1748e9e28f2b03 ee3341fd8bdb3e6f157b088efca1d06b 4345faca71e1f388182af8e9621026b8"
                ;;
                * )
                    logmsg "I" "update" "huh. unknown custom font for md5 checks. that shouldn't happen"
                ;;
            esac
            # And perform the actual check
            font_md5_match="false"
            # Check if it exists at all...
            if [ -f /mnt/us/${HACKNAME}/fonts/${current_font} ] ; then
                font_current_md5=$( md5sum /mnt/us/${HACKNAME}/fonts/${current_font} | awk '{ print $1; }' )
                for cur_exp_md5 in ${font_expected_md5} ; do
                    if [ "${font_current_md5}" == "${cur_exp_md5}" ] ; then
                        font_md5_match="true"
                    fi
                done
                if [ "${font_md5_match}" != "true" ] ; then
                    HACK_EXCLUDE="${HACK_EXCLUDE} ${HACKNAME}/fonts/${current_font}"
                    logmsg "I" "update" "found custom font ${current_font}, excluding from archive"
                fi
            else
                logmsg "I" "update" "custom font ${current_font} was missing, it'll be installed"
            fi
        done
    done
    # And also loop through the new K3 fonts
    for font in CJK I18N ; do
        current_font="${font}.ttf"
        # Select the correct expected md5sum for our current font
        case "${current_font}" in
            "CJK.ttf" )
                font_expected_md5="939889bec9cda51381a5065df3a3bbfd 5931b08bba8127286c06ea0061df0088 4caeadd734f4be9973163bdf02ea6cf5"
            ;;
            "I18N.ttf" )
                font_expected_md5="eccb7a74720fc377b60d6b2110530fd9 bd298363f255b13c67b55bb1ccb4b581"
            ;;
            * )
                logmsg "I" "update" "huh. unknown custom font for md5 checks. that shouldn't happen"
            ;;
        esac
        # And perform the actual check
        font_md5_match="false"
        # Check if it exists at all...
        if [ -f /mnt/us/${HACKNAME}/fonts/${current_font} ] ; then
            font_current_md5=$( md5sum /mnt/us/${HACKNAME}/fonts/${current_font} | awk '{ print $1; }' )
            for cur_exp_md5 in ${font_expected_md5} ; do
                if [ "${font_current_md5}" == "${cur_exp_md5}" ] ; then
                    font_md5_match="true"
                fi
            done
            if [ "${font_md5_match}" != "true" ] ; then
                HACK_EXCLUDE="${HACK_EXCLUDE} ${HACKNAME}/fonts/${current_font}"
                logmsg "I" "update" "found custom font ${current_font}, excluding from archive"
            fi
        else
            logmsg "I" "update" "custom font ${current_font} was missing, it'll be installed if you're on FW 3.x"
        fi
    done
    # Original fonts
    ORIG_FONT_LIST="Caecilia_LT_65_Medium Caecilia_LT_66_Medium_Italic Caecilia_LT_75_Bold Caecilia_LT_76_Bold_Italic Helvetica_LT_65_Medium Helvetica_LT_66_Medium_Italic Helvetica_LT_75_Bold Helvetica_LT_76_Bold_Italic KindleBlackboxBoldItalic KindleBlackboxBold KindleBlackboxItalic KindleBlackboxRegular Kindle_MonospacedSymbol Kindle_Symbol"
    # And the new K3 fonts
    ORIG_FONT_LIST="${ORIG_FONT_LIST} Caecilia_LT_67_Cond_Medium Caecilia_LT_68_Cond_Medium_Italic Caecilia_LT_77_Cond_Bold Caecilia_LT_78_Cond_Bold_Italic code2000 HangulGothMTC_E_Bold HangulGothMTC_E HeiSeiMaruGoth213_E_Bold HeiSeiMaruGoth213_E MHeiM18030_E_Bold MHeiM18030_E MHeiM-Big5HKSCS_E_Bold MHeiM-Big5HKSCS_E"
    # Loop through our copy of all the original fonts to remove them, in case they've been updated by an official fw update. The hack will reinstall them on the next run.
    for original_font in ${ORIG_FONT_LIST} ; do
        if [ -f /mnt/us/${HACKNAME}/fonts/${original_font}.ttf ] ; then
            logmsg "I" "update" "removing possibly outdated hack copy of the original font ${original_font}"
            rm -f /mnt/us/${HACKNAME}/fonts/${original_font}.ttf
        fi
    done
    # Cleanup the backed up default libfreetype used for the browser
    if [ -f /mnt/us/${HACKNAME}/lib/libfreetype.so.6 ] ; then
        logmsg "I" "update" "removing possibly outdated hack copy of the original freetype lib"
        rm -f /mnt/us/${HACKNAME}/lib/libfreetype.so.6
    fi
fi

update_progressbar 42

# Okay, now we can extract it. Since busybox's tar is very limited, we have to use a tmp directory to perform our filtering
logmsg "I" "update" "installing custom directory"
tar -xvzf ${HACKNAME}.tar.gz

# That's very much inspired from official update scripts ;)
cd src
# And now we filter the content to preserve user's custom content
for custom_file in ${HACK_EXCLUDE} ; do
    if [ -f "./${custom_file}" ] ; then
        logmsg "I" "update" "preserving custom content (${custom_file})"
        rm -f "./${custom_file}"
    fi
done
# Finally, re-tape our filtered dir and unleash it on the live userstore
tar cf - . | (cd /mnt/us ; tar xvf -)
_RET=$?
if [ ${_RET} -ne 0 ] ; then
    logmsg "C" "update" "code=${_RET}" "failure to update userstore with custom directory"
    return 1
fi
cd - >/dev/null
rm -rf src

update_progressbar 48

# Install our hack's init script
logmsg "I" "update" "installing init script"
cp -f ${HACKNAME}-init /etc/init.d/${HACKNAME}

update_progressbar 54

# Make it executable
logmsg "I" "update" "chmoding init script"
[ -x /etc/init.d/${HACKNAME} ] || chmod +x /etc/init.d/${HACKNAME}

update_progressbar 60

# Make it start at boot (rc5), after dbus and before pmond and the framework
logmsg "I" "update" "creating boot runlevel symlink"
[ -h /etc/rc5.d/S${SLEVEL}${HACKNAME} ] || ln -fs /etc/init.d/${HACKNAME} /etc/rc5.d/S${SLEVEL}${HACKNAME}

update_progressbar 66

# Make it stop at reboot (rc6), after the framework and before userstore
logmsg "I" "update" "creating reboot runlevel symlink"
[ -h /etc/rc6.d/K${KLEVEL}${HACKNAME} ] || ln -fs /etc/init.d/${HACKNAME} /etc/rc6.d/K${KLEVEL}${HACKNAME}

update_progressbar 72

# Make it stop at shutdown (rc0), after the framework and before userstore
logmsg "I" "update" "creating shutdown runlevel symlink"
[ -h /etc/rc0.d/K${KLEVEL}${HACKNAME} ] || ln -fs /etc/init.d/${HACKNAME} /etc/rc0.d/K${KLEVEL}${HACKNAME}

update_progressbar 78

# Make it stop when updating (rc3), after the framework and before the updater
logmsg "I" "update" "creating update runlevel symlink"
[ -h /etc/rc3.d/K${KLEVEL}${HACKNAME} ] || ln -fs /etc/init.d/${HACKNAME} /etc/rc3.d/K${KLEVEL}${HACKNAME}

update_progressbar 84

# From v4.2.N
# Install a default dummy env file for browserd, because pmond craps out at a blank file... FW 3.x only
logmsg "I" "update" "creating default browser workaround file"
if [ -d /etc/kdb/system/daemon/pmond/browserd ] ; then
    # Only create it if there's not already one there... (With current FW releases, there's not)
    if [ ! -f /etc/kdb/system/daemon/pmond/browserd/env ] ; then
        logmsg "I" "update" "default browser workaround file installed"
        echo -en "RG002\n40\n<DATA>\nOH_HAI_LINKFONTS=true" > /etc/kdb/system/daemon/pmond/browserd/env
    fi
    # Make sure the perms are right, or pmond throws a fit
    chmod 644 /etc/kdb/system/daemon/pmond/browserd/env
fi

update_progressbar 90

# From v4.2
# Install our proper fixed env file in /var/local, because a bindmount inherits perms, and pmond doesn't like the crappy vfat perms we can't change
logmsg "I" "update" "creating browser workaround file"
# Make sure we've got somewhere to put it ;)
[ -d /var/local/${HACKNAME} ] || mkdir -p /var/local/${HACKNAME}
# Create it
echo -en "RG002\n40\n<DATA>\nLD_LIBRARY_PATH=/mnt/us/${HACKNAME}/lib" > /var/local/${HACKNAME}/env
# And make sure the perms are right
chmod 644 /var/local/${HACKNAME}/env

update_progressbar 96

# Cleanup
logmsg "I" "update" "cleaning up"
rm -f ${HACKNAME}-init ${HACKNAME}.tar.gz

update_progressbar 98

logmsg "I" "update" "done"
update_progressbar 100

return 0
